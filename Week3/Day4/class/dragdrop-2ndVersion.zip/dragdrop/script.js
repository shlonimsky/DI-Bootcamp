function retrieveDragItem () {
    const allItem = document.getElementsByClassName("draggedItem")
    for(let item of allItem){
        item.setAttribute("draggable", true);
        item.addEventListener("dragstart", startDragging);
    }
}

retrieveDragItem()

//1. Use dragStart event
function startDragging(evt){
    evt.target.classList.add("startDrag");
    evt.dataTransfer.setData("text/plain", evt.target.id);
    //use the dataTransfer o bject, to set the data that we want to drop in the future
    // console.log(evt.target.id);
    // console.log(evt.target); //box I drag
}

//2. Retrieve all the dropzones
function retrieveZonesAndAddEvents () {
    const allZones = document.querySelectorAll(".dropzone");
    // Give to each dropzone an event listener; loop
    for (let zone of allZones) {
        zone.addEventListener("dragover", overTarget);
        zone.addEventListener("drop", dropOnTarget);
    }
}

retrieveZonesAndAddEvents()


function overTarget (evt) {
    evt.preventDefault(); //necessary
    evt.target.classList.add("overDrop");
}

function dropOnTarget (evt) {
    evt.preventDefault();  //necessary
    evt.target.classList.add("droppedTarget");
    const data = evt.dataTransfer.getData("text/plain"); //id of the element
    // console.log(data);
    const elem = document.getElementById(data);
    evt.target.appendChild(elem);
}