// // Create a function that takes in a single parameter and returns a new promise.
// // Using setTimeout, after 5000 milliseconds, the promise will either resolve or reject.
// // If the input is a string, the promise resolves with that same string uppercased.
// // If the input is anything but a string it rejects with that same input.
// // Use then to repeat the string twice use catch to console.log the error 
// // finally call a function that console.log ("congratulation")


function checkInput (inputUser) {
    return new Promise(function (resolve, reject) {
        setTimeout(function () {
            if(typeof inputUser === "string") {
                resolve(inputUser.toUpperCase());
            } else {
                reject(inputUser);
            }
        }, 2000)
    })
}

// //consume the promise
checkInput("hello")
.then((resOne) => {
    // throw new Error("Some error");
    // return Promise.reject("Some Error");
    return resOne.repeat(2);
})
.then((resTwo) => {
    console.log(resTwo);
})
.catch((err) => {
    console.log("IN THE CATCH - THE ERROR IS", err);
})





// checkInput(2)
// .then((resOne) => {
//     console.log(resOne.repeat(2));
// })
// .catch((err) => {
//     console.log("IN THE CATCH - THE ERROR IS", err);
// })

const workWell = true;

function getGift () {
    return new Promise(function(resolve, reject){
        setTimeout(function (){
            if(workWell) {
                const gift = "Phone";
                resolve(gift);
            } else {
                reject("You receive nothing")
            }
        }, 2000)
    })
}

function getVacation () {
    return new Promise(function(resolve, reject){
        setTimeout(function (){
            if(workWell) {
                const vacation = "Spain";
                resolve(vacation);
            } else {
                reject("You receive nothing")
            }
        }, 2000)
    })
}


getGift()
.then((resOne) => {
    console.log(resOne);
    const data = getVacation();
    return data; //then method, we always to return a value so it consumed by the then()
})
.then((resTwo) => {
    console.log(resTwo);
})