// const myform = document.getElementById("myForm");
// // document.querySelector("#myForm");
// // document.forms[0]
// // document.forms.myForm

// myform.addEventListener("submit", retrieveData);

// //retrieve the input
// // myform.children[1]
// // myform.children.username


// //with submit event, we need e.preventDefault()
// function retrieveData (e) {
//     e.preventDefault();
//     console.log(e);
//     // console.log(e.target[0], e.target.username);
//     const inputForm = e.target.username;
//     const inputValue = inputForm.value;
//     console.log(inputValue);
// }


// const inputUsername = document.getElementById("username");

// inputUsername.addEventListener("input", test)

// function test (e) {
//     console.log(e.target.value);
// }

// inputUsername.addEventListener("keydown", test)

// function test (e) {
//     console.log("e.key" , e.key);
//     console.log("e.target.value" , e.target.value);
// }

// const selectAge = document.getElementById("age");

// selectAge.addEventListener("change", test) //and for radio button

// function test (e) {
//     console.log(e.target.value);
// }

const robots = [
    {
      id: 1,
      name: 'Leanne Graham',
      username: 'Bret',
      email: 'Sincere@april.biz',
      image: 'https://robohash.org/1?200x200'
    },
    {
      id: 2,
      name: 'Ervin Howell',
      username: 'Antonette',
      email: 'Shanna@melissa.tv',
      image: 'https://robohash.org/2?200x200'
    },
    {
      id: 3,
      name: 'Clementine Bauch',
      username: 'Samantha',
      email: 'Nathan@yesenia.net',
      image: 'https://robohash.org/3?200x200'
    },
    {
      id: 4,
      name: 'Patricia Lebsack',
      username: 'Karianne',
      email: 'Julianne.OConner@kory.org',
      image: 'https://robohash.org/4?200x200'
    },
    {
      id: 5,
      name: 'Chelsey Dietrich',
      username: 'Kamren',
      email: 'Lucio_Hettinger@annie.ca',
      image: 'https://robohash.org/5?200x200'
    }
];


const container = document.getElementById("container");

function displayRobot () {
    robots.forEach((robot) => {
        //destructure
        const {name, email, image} = robot;
        //create elements
        const card = document.createElement("div");
        const imageRobot = document.createElement("img");
        const nameP = document.createElement("p");
        const emailP = document.createElement("p");
        // create values
        const nameValue = document.createTextNode(name);
        const emailValue = document.createTextNode(email);
        nameP.appendChild(nameValue);
        emailP.appendChild(emailValue);
        imageRobot.src = image;
        // imageRobot.setAttribute("src",image);


        card.classList.add("cardRobot");
        card.append(imageRobot, nameP, emailP);
        container.appendChild(card);
    })
}

displayRobot()